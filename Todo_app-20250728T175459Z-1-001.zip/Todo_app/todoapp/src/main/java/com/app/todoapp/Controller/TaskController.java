package com.app.todoapp.Controller;

import com.app.todoapp.models.Task;
import com.app.todoapp.services.TaskService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // Show all tasks
    @GetMapping
    public String getTasks(Model model) {
        List<Task> tasks = taskService.getAllTasks();
        model.addAttribute("tasks", tasks);
        return "tasks";
    }

    // Add a new task
    @PostMapping
    public String addTask(@RequestParam("title") String title) {
        Task newTask = new Task();
        newTask.setTitle(title);
        newTask.setCompleted(false);
        taskService.saveTask(newTask);
        return "redirect:/tasks"; // Redirect back to the task list


    }
        @GetMapping("/{id}/delete")
        public String deleteTask(@PathVariable Long id) {
            taskService.deleteTaskById(id);
            return "redirect:/tasks"; // go back to list after deletion
        }

    @GetMapping("/{id}/toggle")
    public String ToggleTask(@PathVariable Long id) {
        taskService.toggleTask(id);
        return "redirect:/tasks"; // go back to list after deletion
    }
    }

